Nomor Kelompok : Kelompok 3
Nama Proyek : Aplikasi Lelang Padi

									Aplikasi Lelang Padi


Website lelang padi merupakan suatu website dimana petani dapat melelang padi yang dimilikinya terhadap petani lain atau masyarakat.
Setelah petani melakukan pelelangan, maka user yang lain akan melihat pelelangan padi tersebut dan menawarnya. Proses pelelangan padi
ditentukan dalam waktu 3-5 hari. Setelah waktu yang telah ditentukan berakhir, maka pemenang dari penawaran tersebut akan langsung diumumkan
pada detail padi yang dilelang. Pemenang ditentukan dari penawaran tertinggi dari pelelangan padi yang ditentukan. Setelah itu pemenang harus
melakukan proses pembayaran yang telah ditentukan yaitu dengan menggunakan kartu kredit, dimana saldo dari pemenang tersebut akan otomatis berkurang
dan saldo dari petani yang melelang padi akan bertambah.
 

Langkah-Langkah dalam mengakses website:

I. Melakukan Pelelangan

1. User harus terlebih dahulu melakukan sign up. User terdiri dari pelelang (orang yang melakukan lelang) dan penawar (orang yang melakukan penawaran terhadap padi yang dilelang).
Pada saat melakukan sign up, hal yang harus dan perlu diisi oleh user adalah dengan mengisi Nomor Kartu Kredit. Hal tersebut berguna untuk proses pembayaran terhadap penawaran yang
dilakukan jika user adalah pemenang dari lelang padi tersebut.
2. Ketika user ingin melelang, maka user harus terlebih dahulu memilih tombol "Lelang".
3. Pada halaman lelang, user harus menekan tombol "Lelang Padi".
3. Ketika sudah menekan tombol lelang, user harus mengisi form tambah lelang. Form tambah lelang terdiri dari Jenis Padi, Deskripsi Padi, Massa Padi, Harga per kg, Waktu Akhir pelelangan,
serta mengupload gambar padi yang ingin dilelang dan menekan tombol "Create". Ketentuan waktu dalam melelang adalah 3-5 hari.
4. Setelah menekan tombol "create" maka produk padi akan otomatis ditambahkan di halaman home.


II. Melakukan Penawaran

1. Ketika user ingin melakukan penawaran, di halaman HOME terdapat produk padi yang dilelang. Pada saat user ingin melakukan penawaran user terlebih dahulu
menekan tombol "tawar". Pada saat menekan tombol "tawar" akan muncul pop up form penawaran. Form penawaran terdiri dari Tanggal tawar (sudah otomatis terisi), harga per kg padi,
massa padi, kelipatan, kenaikan penawaran, harga padi, harga penawaran.

Pada form ini, yang harus diisi user adalah kelipatan penawaran yang ingin dilakukan.
Misalnya Harga padi per kg Rp 10000
Massa Padi 10 kg
Harga Padi 100000
User ingin menawar dengan mengisi kelipatan penawaran sebesar 2.
Maka kenaikan penawaran yang didapatkan adalah = kelipatan penawaran * massa padi * 100. 100 merupakan ketentuan dimana pada saat menawar user harus melakukan kelipatan padi Rp 100/kg.
Oleh karena itu didapatkan Kenaikan penawaran = 2000 dan Harga penawaran didapatkan dari kenaikan penawaran + harga padi. 
Harga Penawaran = 100000 + 2000 = 102000

Kemudian user menekan tombol "create".

Harga penawaran akan terus berubah-ubah dan bertambah selama waktu yang ditentukan oleh pelelang padi yaitu 3-5 hari.



2. Ketika selesai melakukan proses penawaran, user akan melihat detail dari produk yang ditawar tersebut.

3. User juga dapat menekan tombol "lelang" untuk melihat produk padi yang sudah habis masa lelangnya atau produk padi yang masih berlaku
masa lelangnya. Untuk melihat detail produk yang dilelang user dapat menekan tombol "Lihat Lelangan". Setelah menekan tombol, user akan melihat
detail dari produk padi. User dapat memberikan review terhadap produk padi dengan cara menekan tombol review dan akan langsung dibawa ke halaman email.
User dapat memberikan email kepada pelelang dengan isi email berupa review padi yang dilelang. Kemudian user juga dapat melihat Pemenang pelelangan padi
yang dilelang.

4. User dengan id yang sama tidak dapat menawar produk yang sama secara berturut-turut. 

III. Memilih Pemenang

1. Pemenang ditentukan dari user yang menawar produk padi dengan penawaran tertinggi pada waktu akhir dari pelelangan padi yang telah ditentukan.
2. Pelelang akan mengumumkan siapa yang menjadi pemenang di detail produk lelang padi nya.
3. Semua user dapat melihat pemenang lelang.
4. Yang menang yang hanya dapat melakukan pembayaran. Jadi, jika user yang tidak menang ingin melakukan pembayaran maka akan muncul notifikasi bahwa user
tersebut bukan pemenang maka tidak dapat melakukan pembayaran.

IV. Proses Pembayaran
1. Pemenang harus menekan tombol "bayar sekarang"
2. Setelah menekan tombol, pemenang akan langsung masuk ke proses pembayaran.
3. Pada form transfer, user harus mengisi Account No, FullName, PIN, Expire Month, Expire Year.
4. Setelah itu user menekan tombol pay.

Maka saldo dari pemenang akan langsung berkurang secara otomatis sesuai harga penawaran yang dibuatnya.
Dan Saldo dari pelelang produk padi akan otomatis bertambah.


