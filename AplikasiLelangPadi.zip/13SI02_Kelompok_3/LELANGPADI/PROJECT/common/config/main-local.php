<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=lelangpadi',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],

//ini mail untuk contact

'mailer' => [
    'class' => 'yii\swiftmailer\Mailer',
    'viewPath' => '@common/mail',
    'useFileTransport' => false,
    'transport' => [
        'class' => 'Swift_SmtpTransport',
        'host' => gethostbyname('smtp.gmail.com'),
        'username' => 'riahta.mei38@gmail.com',
        'password' => 'meiketaren038!',
        'port' => '465',
        'encryption' => 'ssl',
        
         'streamOptions' => [ 'ssl' =>
                [ 'allow_self_signed' => true,
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                ],
            ],
    ],

    ],




//     'paypal'=> [
//     'class'        => 'marciocamello\Paypal',
//     'clientId'     => 'you_client_id',
//     'clientSecret' => 'you_client_secret',
//     'isProduction' => false,
//      // This is config file for the PayPal system
//      'config'       => [
//          'http.ConnectionTimeOut' => 30,
//          'http.Retry'             => 1,
//          'mode'                   => \marciocamello\Paypal::MODE_SANDBOX, // development (sandbox) or production (live) mode
//          'log.LogEnabled'         => YII_DEBUG ? 1 : 0,
//          'log.FileName'           => '@runtime/logs/paypal.log',
//         'log.LogLevel'           => \marciocamello\Paypal::LOG_LEVEL_FINE,
//     ]
// ],



],
];
