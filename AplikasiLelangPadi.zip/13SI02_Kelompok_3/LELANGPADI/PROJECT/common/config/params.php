









<?php
return [
    'adminEmail' => 'iss15047@students.del.ac.id',
    'api_key' => 'ca5d7114190bb6ba7100061bb75d9bc01dfc57911c51530a2a304f7c7191a4ee',

    // 'api_key' => '9e52b87c213c0245b0345a25fe44d2fe09d4689afee36ca56cf2571dcc594d0d', //api key pak mario

    'merchant_account_no' => '0105040004',
    'sikilat' => 'https://sigurita.com/sikilat/account/payment'
    
    // 'supportEmail' => 'riahta.mei38@gmail.com',
    // 'user.passwordResetTokenExpire' => 3600,
];

