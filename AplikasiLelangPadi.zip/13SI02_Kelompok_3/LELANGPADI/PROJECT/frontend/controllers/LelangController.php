<?php

namespace frontend\controllers;

use Yii;
use frontend\models\Lelang;
use frontend\models\LelangSearch;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\data\ActiveDataProvider;
use yii\helpers\Url;
use yii\web\ForbiddenHttpException;
use yii\web\UploadedFile;
use frontend\models\Tawar;
use frontend\models\User;
// use kartik\alert\Alert;
use common\widgets\Alert;
use yii\helpers\Json;

/**
 * LelangController implements the CRUD actions for lelang model.
 */
class LelangController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],






        ];
    }



    /**
     * Lists all lelang models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new LelangSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single lelang model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }







 public function actionViewku($id)
    {        
        return $this->render('view2', [ 'id' => $id,
            'model' => $this->findModel($id),
        ]);
    }





// tambahan






















    public function actionWinner($id){


//mendapatkan nilai penawaran tertinggi
$penawaranTertinggi = Tawar::Find()->where(['id_lelang'=> $id])->all();

$max = 0;
$idUser = 0;

foreach ($penawaranTertinggi as $key => $tawar) {
    if($max < $tawar->hargapenawaran){
        $max = $tawar->hargapenawaran;
        $idUser = $tawar->id_penawar;
    }
}

$idPemenang = $idUser;

// var_dump($idPemenang);die();

 $model = new tawar();
$modelel = new lelang();

$modelel = $this->findModels($id);

$user = User::findOne($modelel->id_pelelang);
                
$nokartukredit = $user->nokartukredit;


$hargapenawaran = (new \yii\db\Query())
                    ->select('max(hargapenawaran)')
                    ->from('tawar')
                    ->where(['id_penawar' => $idUser, 'id_lelang' => $id])
                    ->scalar();


$namalengkapPemenang = (new \yii\db\Query())
                    ->select('namalengkap')
                    ->from('user')
                    ->where(['id' => $idUser])
                    ->scalar();

$emailPemenang = (new \yii\db\Query())
                    ->select('email')
                    ->from('user')
                    ->where(['id' => $idUser])
                    ->scalar();

$usernamePemenang = (new \yii\db\Query())
                    ->select('username')
                    ->from('user')
                    ->where(['id' => $idUser])
                    ->scalar();

$alamatPemenang = (new \yii\db\Query())
                    ->select('alamat')
                    ->from('user')
                    ->where(['id' => $idUser])
                    ->scalar();


return $this->render('view2',[
    'model'=> $this->findModel($id), 
    'hargapenawaran' => $hargapenawaran,
    'email' => $emailPemenang, 
    'namalengkap' => $namalengkapPemenang, 
    'username' => $usernamePemenang,
    'idPemenang' => $idPemenang
    ]);
}



    /**
     * Creates a new lelang model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Lelang();
       // $model = $this->findModel($id);
        
        $model->id_pelelang = Yii::$app->user->identity->id;

        if ($model->load(Yii::$app->request->post())) {

            $datagambar = UploadedFile::getInstance($model,'gambar');
                        // var_dump($datagambar->name);die();
                       $model->gambar = $datagambar->name; 
                       // var_dump($model->validate());die();
            $datagambar->saveAs('images/'.$datagambar->baseName.'.'.$datagambar->extension);    
            
            $model->harga_padi;

            $model->waktu_awal = date('Y-m-d');

            $waktu_awal = new \DateTime ($model->waktu_awal);

            $waktu_akhir = new \DateTime ($model->waktu_akhir);
            $hari = $waktu_awal->diff($waktu_akhir);
            $hari = $hari->d;
            
                                    //var_dump($model->waktu_awal);die();
            $model->status = 1;
            if($hari <= 5 && $hari > 0 ){

                $model->save();

                return $this->redirect(['view', 'id' => $model->id_lelang]);
            }

            else{

            Yii::$app->session->setFlash('error', 'Tidak dapat membuat Lelang! 
                Waktu Akhir berjarak 3 s.d 5 hari dari hari ini. Silahkan buat ulang Lelang Padi Anda');


//                 echo Alert::widget([
//     'type' => Alert::TYPE_INFO,
//     'title' => 'Note',
//     'titleOptions' => ['icon' => 'info-sign'],
//     'body' => 'This is an informative alert'
// ]);

                return $this->redirect(['index']);
            }




//cara mendapatkan id user yang sedang login
            $userId = \Yii::$app->user->identity->id;

            $model->id_pelelang =$userId;

            // $model->id_pelelang = Yii::app()->user->getId();
// var_dump($model->id_pelelang);die();

                                     //var_dump($model->waktu_awal);die();
            // $model->status = 1;
            $model->save();

            return $this->redirect(['view', 'id' => $model->id_lelang]);
        } else {
            return $this->renderAjax('create', [    
                'model' => $model,
            ]);
        }
    }






public function actionSikilat($id, $hargapenawaran)
    {

$penawaranTertinggi = Tawar::Find()->where(['id_lelang'=> $id])->all();

$max = 0;
$idUser = 0;

foreach ($penawaranTertinggi as $key => $tawar) {
    if($max < $tawar->hargapenawaran){
        $max = $tawar->hargapenawaran;
        $idUser = $tawar->id_penawar;
    }
}

$idPemenang = $idUser;
$userId = Yii::$app->user->identity->id;

if($idPemenang == $userId){

     $model = new tawar();
$modelel = new lelang();

$modelel = $this->findModels($id);

$user = User::findOne($modelel->id_pelelang);
                
$nokartukredit = $user->nokartukredit;




    
    
                $model->id_penawar = Yii::$app->user->identity->id;
                
                $model->id_lelang = $id;

 
                $model->generateSequence();
                // $model->calculate();
                
                $session = Yii::$app->session;
                $buyings = [];
                if ($session->has('buyings')){
                    $buyings = $session->get('buyings');
                }
                $buyings[$model->seq] = $model;
                $session->set('buyings', $buyings);
                
                $params = [
                    'api_key' => Yii::$app->params['api_key'],

                    //ini kalo receiver_no diambil dari param
                                // 'receiver_no' => Yii::$app->params['merchant_account_no'],

                    //ini kalo receiver_no diambil dari id lelangnya
                    // 'receiver_no' => $no_mercant,
                    // 'receiver_no' => "".$user->nokartukredit,
                  'receiver_no' => $nokartukredit,

                    'amount' => $hargapenawaran,
                    'code' => $model->seq
                ];

                $sikilatUrl  = Yii::$app->params['sikilat'] . "?data=" . Json::encode($params);
                
                Yii::$app->response->redirect($sikilatUrl);
                Yii::$app->end();


}
else{
    Yii::$app->getSession()->setFlash('danger', 'Maaf, Anda bukan Pemenang Lelang');
                return $this->redirect(['site/index']);  
}

    } 
























    /**
     * Updates an existing lelang model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */

 public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }



    /**
     * Deletes an existing lelang model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {

        
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the lelang model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return lelang the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = lelang::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }


    protected function findModels($id)
    {
        if (($model = lelang::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }



    //  protected function isUserAuthor()
    // {   
    //     return $this->findModel(Yii::$app->request->get('id'))->user->id == Yii::$app->user->id;
    // }
}
