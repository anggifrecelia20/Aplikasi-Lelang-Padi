<?php

namespace frontend\controllers;

use Yii;
use frontend\models\Tawar;
use frontend\models\User;
use frontend\models\lelang;
use frontend\models\TawarSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\helpers\Json;
use yii\helpers\Url;
use yii\web\ErrorAction;
use yii\filters\VerbFilter;
use common\widgets\Alert;

/**
 * TawarController implements the CRUD actions for Tawar model.
 */

class TawarController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Tawar models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new TawarSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }


    /**
     * Displays a single Tawar model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }


    /**
     * Creates a new Tawar model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Tawar();

        if ($model->load(Yii::$app->request->post())) {

            $model->id_lelang = 19;
            $model->id_penawar = 2;
            
            $model->save();
            return $this->redirect(['view', 'id' => $model->id_tawar]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

















//     public function actionCreatess($id_lelang)
//     {

//         $model = new tawar();
//         $modelel = new lelang();

//         $modelel = $this->findModels($id_lelang);

//         $user = User::findOne($modelel->id_pelelang); //tangkap id pelelang
// //var_dump($user);die();

//         //tangkap nokartukreditpelelang, tampung ke dalam no_merchant

//          $no_mercant = $user->nokartukredit; //ubah ke string

// // echo $no_mercant; die();

//         if ($model->load(Yii::$app->request->post())) {


//              // $model->id_pelelang = Yii::$app->user->identity->id;
            
//             $model->id_penawar = Yii::$app->user->identity->id;

//             $model->id_lelang = $id_lelang;


//             if($model->save()){
//                 $model->generateSequence();
//                 $model->calculate();
                
//                 $session = Yii::$app->session;
//                 $buyings = [];
//                 if ($session->has('buyings')){
//                     $buyings = $session->get('buyings');
//                 }
//                 $buyings[$model->seq] = $model;
//                 $session->set('buyings', $buyings);
                
//                 $params = [
//                     'api_key' => Yii::$app->params['api_key'],

//                     //ini kalo receiver_no diambil dari param
//                                 // 'receiver_no' => Yii::$app->params['merchant_account_no'],

//                     //ini kalo receiver_no diambil dari id lelangnya
//                     // 'receiver_no' => $no_mercant,
//                     // 'receiver_no' => "".$user->nokartukredit,
//                   'receiver_no' => $no_mercant,

//                     'amount' => $model->hargapenawaran,
//                     'code' => $model->seq
//                 ];
                
//                 $sikilatUrl  = Yii::$app->params['sikilat'] . "?data=" . Json::encode($params);
                
//                 Yii::$app->response->redirect($sikilatUrl);
//                 Yii::$app->end();

//             }
//             // return $this->redirect(['view', 'id' => $model->id_tawar]);
//             else{
//                 return $this->renderAjax('create', [
//                     'model' => $model,
//                     'modelel' => $modelel,
//                 ]);
//             }
//         } 


//         else {
//                 $model->id_lelang = $id_lelang;
//                 $model->tanggaltawar = date('Y-m-d');

//                  $penawaranPertama = (new \yii\db\Query())
//                     ->select ('harga_padi')
//                     ->from('lelang')
//                     ->where(['id_lelang' => $this->findModels($id_lelang)])
//                     ->scalar();


                // $tawaran = (new \yii\db\Query())
                //     ->select ('massapadi')
                //     ->from('lelang')
                //     ->where(['id_lelang' => $this->findModels($id_lelang)])
                //     ->scalar();

//             $rows = (new \yii\db\Query())
//                     ->select ('max(hargapenawaran)')
//                     ->from('tawar')
//                     ->where(['id_lelang' => $this->findModels($id_lelang)])
//                     ->scalar();

                    
//             if($penawaranPertama < $rows){
//                 $model->hargapadi = $rows;
//             }
//             else
//                 $model->hargapadi = $penawaranPertama;

//             return $this->renderAjax('create', [
//                 'model' => $model,
//                 'modelel' => $modelel,
                
//             ]);
//         }

//         $model->save();

// //         if($model->save()){
// // $insert_id = Yii::app()->db->getLastInsertID();
// // // var_dump($insert_id);die(); 
// //         }
        
//         $model->generateSequence();
//         $model->calculate();
    
//         $session = Yii::$app->session;
//         $buyings = [];
//         if ($session->has('buyings')){
//             $buyings = $session->get('buyings');
//         }
//         $buyings[$model->seq] = $model;
//         $session->set('buyings', $buyings);
        
//         $params = [
//             'api_key' => Yii::$app->params['api_key'],
//                             // 'receiver_no' => Yii::$app->params['merchant_account_no'],
//             // 'receiver_no' => $no_mercant,

//               'receiver_no' => "$user->nokartukredit",
//             'amount' => $model->hargapenawaran,
//             'code' => $model->seq
//         ];
        
//         $sikilatUrl  = Yii::$app->params['sikilat'] . "?data=" . Json::encode($params);
        
//         Yii::$app->response->redirect($sikilatUrl);
//         Yii::$app->end();
//     }
























   public function actionCreatess($id_lelang)
    {

        

                $model = new tawar();
                $modelel = new lelang();

                $modelel = $this->findModels($id_lelang);

                //var_dump($modelel->jenis_padi);die();


        if ($model->load(Yii::$app->request->post())) {
            $modelTawar = Tawar::find()->orderBy(['id_tawar' => SORT_DESC])->one();
            if($modelTawar == null){
                $model->id_penawar = Yii::$app->user->identity->id;
            $model->id_lelang = $id_lelang;

        
        // $model->hargapadi = $rows + $tawarani;
            // var_dump($model);die();

        if($model->save())
            return $this->redirect(['view', 'id' => $model->id_tawar]);

        else
            return $this->renderAjax('create', [
                'model' => $model,
                'modelel' => $modelel,
            ]);    
            }else if($modelTawar->id_penawar != Yii::$app->user->identity->id){
                $model->id_penawar = Yii::$app->user->identity->id;
            $model->id_lelang = $id_lelang;

        
        // $model->hargapadi = $rows + $tawarani;
            // var_dump($model);die();

        if($model->save())
            return $this->redirect(['view', 'id' => $model->id_tawar]);

        else
            return $this->renderAjax('create', [
                'model' => $model,
                'modelel' => $modelel,
            ]);
    }else{
        \Yii::$app->getSession()->setFlash('danger', 'Tidak dapat menawar berturut - turut');
        return $this->redirect(['site/index']);        
    }
            
// return [
//                 'adminEmail' => 'riahta.mei38@gmail.com',
//                 'api_key' => 'ca5d7114190bb6ba7100061bb75d9bc01dfc57911c51530a2a304f7c7191a4ee',
//                 'merchant_account_no' => '0105040001',
//                 'sikilat' => 'https://sigurita.com/sikilat/account/payment'
//         ]
        } 



        else {

                // $model->massapadi = $massapadi;
                $model->id_lelang = $id_lelang;
                $model->tanggaltawar = date('Y-m-d');

                 $penawaranPertama = (new \yii\db\Query())
                    ->select ('harga_padi')
                    ->from('lelang')
                    ->where(['id_lelang' => $this->findModels($id_lelang)])
                    ->scalar();


                $tawaran = (new \yii\db\Query())
                    ->select ('massapadi')
                    ->from('lelang')
                    ->where(['id_lelang' => $this->findModels($id_lelang)])
                    ->scalar();
// var_dump($tawaran);die();
                    // $tawarani = $tawaran * 100;

                    
//jika belum ada penawaran maka hargapadi adalah hargaawal, jika tidak maka rows + tawarani
//belum bisa


// var_dump($tawarani);die();
            $rows = (new \yii\db\Query())
                    ->select ('max(hargapenawaran)')
                    ->from('tawar')
                    ->where(['id_lelang' => $this->findModels($id_lelang)])
                    ->scalar();

                    
            if($penawaranPertama < $rows){
                $model->hargapadi = $rows;
            }
            else
                $model->hargapadi = $penawaranPertama;


// $model->hargapadi = $penawaranPertama + $tawarani ;

                        // $model->hargapadi = $rows ;

                    // die('masuk');




// return $this->redirect(['index']);


            return $this->renderAjax('create', [
                'model' => $model,
                'modelel' => $modelel,
                
                // var_dump(adminEmail);die();
            ]);
            // 'adminEmail' => 'riahta.mei38@gmail.com',
            //     'api_key' => 'ca5d7114190bb6ba7100061bb75d9bc01dfc57911c51530a2a304f7c7191a4ee',
            //     'merchant_account_no' => '0105040001',
            //     'sikilat' => 'https://sigurita.com/sikilat/account/payment'
        }




// Yii::$app->session->setFlash('error', 'Tidak dapat membuat Lelang! 
                // Waktu Akhir berjarak 3 s.d 5 hari dari hari ini. Silahkan buat ulang Lelang Padi Anda');
// return $this->redirect(['index']);

        $model->save();
    }

    /**
     * Updates an existing Tawar model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */






























    /**
     * Updates an existing Tawar model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id_tawar]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Tawar model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Tawar model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Tawar the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Tawar::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }



protected function findModels($id)
    {
        if (($model = lelang::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
