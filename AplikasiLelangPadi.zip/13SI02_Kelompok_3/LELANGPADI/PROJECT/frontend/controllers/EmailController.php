<?php

namespace frontend\controllers;

use Yii;
use frontend\models\Email;
use frontend\models\EmailSearch;
use frontend\models\User;
use frontend\models\UserSearch;
use frontend\models\Lelang;
use frontend\models\LelangSearch;
use frontend\models\Tawar;
use frontend\models\TawarSearch;

use frontend\controllers\TawarController;



use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * EmailController implements the CRUD actions for Email model.
 */
class EmailController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Email models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new EmailSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Email model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Email model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Email();

        $masuk = Yii::$app->user->identity->id;

 $namalengkap = (new \yii\db\Query())
                    ->select ('namalengkap')
                    ->from('user')
                    ->where(['id' => $masuk])
                    ->scalar();

$model->username_sender = $namalengkap;

 $email = (new \yii\db\Query())
                    ->select ('email')
                    ->from('user')
                    ->where(['id' => $masuk])
                    ->scalar();

$model->sender_email = $email;


        if ($model->load(Yii::$app->request->post()) ) {

           
                $value = Yii::$app->mailer->compose()
                ->setFrom($model->sender_email)
                ->setTo($model->reciever_email)
                ->setSubject($model->subject)
                ->setHtmlBody($model->content)
                ->send();
            
 
            $model->save();


            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }











public function actionWinner($id){
$userId = Yii::$app->user->identity->id;    

$penawaranTertinggi = Tawar::Find()->where(['id_lelang'=> $id])->all();


$idPelelang = (new \yii\db\Query())
                    ->select('id_pelelang')
                    ->from('lelang')
                    ->where(['id_lelang' => $id])
                    ->scalar();

$emailPelelang = (new \yii\db\Query())
                    ->select('email')
                    ->from('user')
                    ->where(['id' => $idPelelang])
                    ->scalar();
$max = 0;
$idUser = 0;

foreach ($penawaranTertinggi as $key => $tawar) {
    if($max < $tawar->hargapenawaran){
        $max = $tawar->hargapenawaran;
        $idUser = $tawar->id_penawar;
    }
}

$emailPenawar = (new \yii\db\Query())
                    ->select('email')
                    ->from('user')
                    ->where(['id' => $idUser])
                    ->scalar();

        $model = new Email();

        $masuk = Yii::$app->user->identity->id;

$model->sender_email = $emailPenawar;

$model->reciever_email = $emailPelelang;


$model->subject = "[Review] Padi";
$model->content = "Kamu adalah Pemenang lelang! Saldo kamu sudah berkurang secara otomatis! Terima kasih :)";

// var_dump($mei);die();

        if ($model->load(Yii::$app->request->post()) ) {

           
                $value = Yii::$app->mailer->compose()
                ->setFrom($model->sender_email)
                ->setTo($model->reciever_email)
                ->setSubject($model->subject)
                ->setHtmlBody($model->content)
                ->send();
            
 
            $model->save();

            
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }

    }


























    /**
     * Updates an existing Email model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Email model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Email model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Email the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Email::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
