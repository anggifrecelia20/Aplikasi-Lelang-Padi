<?php
return [
    'adminEmail' => 'riahta.mei38@gmail.com',
];
