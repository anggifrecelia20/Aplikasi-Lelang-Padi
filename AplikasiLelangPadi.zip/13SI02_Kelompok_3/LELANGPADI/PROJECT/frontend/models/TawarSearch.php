<?php

namespace frontend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use frontend\models\Tawar;

/**
 * TawarSearch represents the model behind the search form about `frontend\models\Tawar`.
 */
class TawarSearch extends Tawar
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_tawar', 'id_lelang', 'id_penawar', 'hargapadi'], 'integer'],
            [['tanggaltawar'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Tawar::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id_tawar' => $this->id_tawar,
            'tanggaltawar' => $this->tanggaltawar,
            'id_lelang' => $this->id_lelang,
            'id_penawar' => $this->id_penawar,
            'hargapadi' => $this->hargapadi,
        ]);

        return $dataProvider;
    }
}
