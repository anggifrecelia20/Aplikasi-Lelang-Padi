<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "tawar".
 *
 * @property integer $id_tawar
 * @property string $tanggaltawar
 * @property integer $id_lelang
 * @property integer $id_penawar
 * @property integer $hargapadi
 * @property integer $kelipatan
 * @property integer $kenaikanpenawaran
 * @property integer $hargapenawaran
 *
 * @property Lelang $idLelang
 * @property User $idPenawar
 * @property TransaksiPembayaran[] $transaksiPembayarans
 */
class Tawar extends \yii\db\ActiveRecord
{
public $seq;
    
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tawar';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['tanggaltawar', 'id_lelang', 'id_penawar', 'hargapadi', 'kelipatan', 'kenaikanpenawaran', 'hargapenawaran'], 'required'],
            [['tanggaltawar'], 'safe'],
            [['id_lelang', 'id_penawar', 'hargapadi', 'kelipatan', 'kenaikanpenawaran', 'hargapenawaran'], 'integer'],
            [['id_lelang'], 'exist', 'skipOnError' => true, 'targetClass' => Lelang::className(), 'targetAttribute' => ['id_lelang' => 'id_lelang']],
            [['id_penawar'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id_penawar' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_tawar' => 'Id Tawar',
            'tanggaltawar' => 'Tanggaltawar',
            'id_lelang' => 'Id Lelang',
            'id_penawar' => 'Id Penawar',
            'hargapadi' => 'Hargapadi',
            'kelipatan' => 'Kelipatan',
            'kenaikanpenawaran' => 'Kenaikanpenawaran',
            'hargapenawaran' => 'Hargapenawaran',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdLelang()
    {
        return $this->hasOne(Lelang::className(), ['id_lelang' => 'id_lelang']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdPenawar()
    {
        return $this->hasOne(User::className(), ['id' => 'id_penawar']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTransaksiPembayarans()
    {
        return $this->hasMany(TransaksiPembayaran::className(), ['id_tawar' => 'id_tawar']);
    }


public function calculate(){
        $this->hargapenawaran = $this->hargapadi + $this->kenaikanpenawaran;
    }
    
    function generateSequence($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        
        $this->seq = "lelangpadi-" . $randomString;
    }

}
