<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "lelang".
 *
 * @property integer $id_lelang
 * @property string $jenis_padi
 * @property string $deskripsi_padi
 * @property string $harga_padi
 * @property string $massapadi
 * @property string $hargaperkg

 */
class Lelang extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public $file;
    public static function tableName(){
             return 'lelang';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['jenis_padi', 'deskripsi_padi', 'harga_padi', 'gambar'], 'required'],
             [['waktu_awal', 'waktu_akhir'], 'safe'],
            [['jenis_padi', 'deskripsi_padi', 'harga_padi', 'gambar', 'massapadi', 'hargaperkg'], 'string', 'max' => 100],
            [['status'],'integer'],
            [['file'],'file'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_lelang' => 'Id Lelang',
            'jenis_padi' => 'Jenis Padi',
            'deskripsi_padi' => 'Deskripsi Padi',
 
            'harga_padi' => 'Harga Padi (Rp)',
            'massapadi' => 'Massa Padi (Kg)',
            'hargaperkg' => 'Harga Per Kg (Rp)',

            'waktu_awal' => 'Waktu Awal',
            'waktu_akhir' => 'Waktu Akhir (Tahun- Bulan - Tanggal)',
            'file' => 'Image',
            'status' => 'Status',
        ];
    }

    public static function getPopulationBetween($lower)
{
    return Lelang::find()
        ->where(['and', "waktu_akhir >= $lower"])
        ->all();
}





// public function calculate(){
//         $this->hargapenawaran = $this->hargapadi + $this->kenaikanpenawaran;
//     }
    
    function generateSequence($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        
        $this->seq = "lelangpadi-" . $randomString;
    }
}
