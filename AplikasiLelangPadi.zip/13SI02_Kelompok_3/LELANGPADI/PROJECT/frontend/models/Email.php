<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "email".
 *
 * @property integer $id
 * @property string $receiver_name
 * @property string $reciever_email
 * @property string $username_sender
 * @property string $sender_email
 * @property string $subject
 * @property string $content
 */
class Email extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'email';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['receiver_name', 'reciever_email', 'username_sender', 'sender_email', 'subject', 'content'], 'required'],
            [['content'], 'string'],
            [['receiver_name'], 'string', 'max' => 50],
            [['reciever_email'], 'string', 'max' => 200],
            [['username_sender', 'sender_email', 'subject'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'receiver_name' => 'Receiver Name',
            'reciever_email' => 'Reciever Email',
            'username_sender' => 'Username Sender',
            'sender_email' => 'Sender Email',
            'subject' => 'Subject',
            'content' => 'Content',
        ];
    }
}
