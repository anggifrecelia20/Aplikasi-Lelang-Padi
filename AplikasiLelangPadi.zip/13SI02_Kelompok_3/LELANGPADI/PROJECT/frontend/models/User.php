<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property integer $id
 * @property string $namalengkap
 * @property string $tanggalahir
 * @property string $alamat
 * @property integer $nohp
 * @property string $username
 * @property string $auth_key
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $email
 * @property integer $status
 * @property integer $created_at
 * @property integer $updated_at
 * @property integer $nokartukredit
 *
 * @property Tawar[] $tawars
 */
class User extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['namalengkap', 'tanggalahir', 'alamat', 'nohp', 'username', 'auth_key', 'password_hash', 'email', 'created_at', 'updated_at', 'nokartukredit'], 'required'],
            [['tanggalahir'], 'safe'],
            [['nohp', 'status', 'created_at', 'updated_at'], 'integer'],
            [['namalengkap', 'alamat'], 'string', 'max' => 100],
            [['username', 'password_hash', 'password_reset_token', 'email', 'nokartukredit'], 'string', 'max' => 255],
            [['auth_key'], 'string', 'max' => 32],
            [['username'], 'unique'],
            [['email'], 'unique'],
            [['password_reset_token'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'namalengkap' => 'Namalengkap',
            'tanggalahir' => 'Tanggalahir',
            'alamat' => 'Alamat',
            'nohp' => 'Nohp',
            'username' => 'Username',
            'auth_key' => 'Auth Key',
            'password_hash' => 'Password Hash',
            'password_reset_token' => 'Password Reset Token',
            'email' => 'Email',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'nokartukredit' => 'Nokartukredit',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTawars()
    {
        return $this->hasMany(Tawar::className(), ['id_penawar' => 'id']);
    }

    // public function namaPengguna($id){
    //     $user = User::find()->where(['id' => $id]) => one();
    //     return $user->username    }
}
