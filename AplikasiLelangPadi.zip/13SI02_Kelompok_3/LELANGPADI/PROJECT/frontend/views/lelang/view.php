<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\grid\GridView;
use frontend\models\Tawar;
use frontend\models\User;
use frontend\models\lelang;


// $modelel = new tawar();


// // $model->id_lelang
   
//    $penawaranPertama = (new \yii\db\Query())
//                     ->select ('max(harga_padi)', 'id_penawar')
//                     ->from('tawar')
//                     ->where(['id_lelang' => $this->findModels($id_lelang)])
//                     ->scalar();
// var_dump($penawaranPertama);die();


/* @var $this yii\web\View */
/* @var $model frontend\models\lelang */

$this->title = $model->id_lelang;


$this->params['breadcrumbs'][] = ['label' => 'Lelang', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="lelang-view">

    <h1><?= Html::encode($this->title) ?></h1>

<p>


         <?= Html::a('Beri Review', ['email/winner', 'id' => $model->id_lelang], [
            'class' => 'btn btn-primary']) ?>




         <?= Html::a('Lihat Pemenang Lelang', ['lelang/winner', 'id' => $model->id_lelang], [
            'class' => 'btn btn-primary']) ?>




             


       <!--  <?= Html::a('Update', ['lelang/update', 'id' => $model->id_lelang], ['class' => 'btn btn-primary']) ?> 
        <?= Html::a('Delete', ['lelang/delete', 'id' => $model->id_lelang], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?> -->


    </p> 

                    
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id_lelang',
            'jenis_padi',
            'deskripsi_padi',
            'massapadi',
            'hargaperkg',
            'harga_padi',
            'waktu_akhir',
            [
                'label' => 'Gambar',
                'attribute' => 'gambar',
                'value'=>function($model)
                {
                    if($model->gambar == NULL || $model->gambar == '-' ){
                        return Yii::getAlias('../../../images').'/no-image.png';
                    }
                    else{
                        return Yii::getAlias('../../frontend/web/images').'/'.$model->gambar;
                    }
                },
                'format' => ['image',
                [
                'width'=> '150',
                'height'=> '170'
                    ]
                ]
            ]
        ],
    ]) ?>

   <!-- <p>
         <?= Html::a('Lihat Pemenang Lelang', ['lelang', 'id' => $model->id_lelang], ['class' => 'btn btn-primary']) ?>
    </p> -->

</div>
