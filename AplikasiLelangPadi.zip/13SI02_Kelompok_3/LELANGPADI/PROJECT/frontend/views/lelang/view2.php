<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\grid\GridView;
use frontend\models\Tawar;
use frontend\models\User;
use frontend\models\lelang;
use frontend\controlles\lelangController;


$userId = Yii::$app->user->identity->id;
// var_dump($userId);die();

$this->title = $model->id_lelang;




$this->params['breadcrumbs'][] = ['label' => 'Lelang', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="lelang-view">

    <h1><?= Html::encode($this->title) ?></h1>

                    
    <?= DetailView::widget([
        
        'model' => $model,
            'attributes' => [
            'id_lelang',
            'jenis_padi',
            'deskripsi_padi',
            'massapadi',
            'hargaperkg',
            'harga_padi',
            'waktu_akhir',
        ],
    ])
     ?>



     <?php echo "Nama Pemenang adalah ",$namalengkap; ?> <br>
     <?php echo "Email Pemenang adalah",$email; ?> <br>
     <?php echo "Id Pemenang",$idPemenang; ?>
<br>

   

         <?= Html::a('Bayar Sekarang!', ['lelang/sikilat', 'id' => $model->id_lelang, 'hargapenawaran' => $hargapenawaran], ['class' => 'btn btn-primary']) ?>
    


</div>
