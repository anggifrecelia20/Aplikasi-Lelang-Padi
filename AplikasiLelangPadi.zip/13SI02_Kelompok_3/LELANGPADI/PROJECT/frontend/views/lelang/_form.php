<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use dosamigos\datepicker\DatePicker;

/* @var $this yii\web\View */
/* @var $model frontend\models\lelang */
/* @var $form yii\widgets\ActiveForm */
?>


    <div class="lelang-form">

        <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

        <?= $form->field($model, 'jenis_padi')->textInput(['maxlength' => true]) ?>

        <?= $form->field($model, 'deskripsi_padi')->textInput(['maxlength' => true]) ?>

        <?= $form->field($model, 'massapadi')->textInput(['id' => 'massaPadi'], ['maxlength' => true, 'id' => 'massapadi']) ?>

        <?= $form->field($model, 'hargaperkg')->textInput(['id' => 'hargaKilo'], ['maxlength' => true, 'id' => 'hargaperkg']) ?>

        <?= $form->field($model, 'harga_padi')->textInput(['id' => 'hargaPadi', 'readonly'=>true], ['maxlength' => true, 'id' => 'harga_padi']) ?>


        <?= $form->field($model, 'waktu_akhir')->widget(
            DatePicker::className(), [
            // inline too, not bad
            //'inline' => true,
            // modify template for custom rendering
            //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
            'clientOptions' => [
                'autoclose' => true,
                'format' => 'yyyy-mm-dd'
            ]
        ]); ?>





        <?= $form->field($model, 'gambar')->fileInput(); ?>

        <div class="form-group">
            <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
        </div>

        <?php ActiveForm::end(); ?>


    </div>


<?php
$script = <<< JS

jQuery(document).ready(function() {
    jQuery('#massaPadi' && '#hargaKilo').change(function() {
    var hargaPadi = document.getElementById('massaPadi').value;
    var hargaKilo = document.getElementById('hargaKilo').value;
    var result = parseInt(hargaPadi) * parseInt(hargaKilo);
    if(!isNaN(result)){
        document.getElementById('hargaPadi').value = result;
    }
    })
})

// $('#massaPadi' && '#hargaKilo').change(function() {
//     var hargaPadi = document.getElementById('massaPadi').value;
//     var hargaKilo = document.getElementById('hargaKilo').value;
//     var result = parseInt(hargaPadi) * parseInt(hargaKilo);
//     if(!isNaN(result)){
//         document.getElementById('hargaPadi').value = result;
//     }
// });

JS;

$this->registerJs($script);
?>