<?php
//file upload.php

$fileName = $_FILES['picture']['name'];
$fileSize = $_FILES['picture']['size'];
$fileError = $_FILES['picture']['error'];
if($fileSize > 0 ||  $fileError ==  0){
	$move = move_uploaded_file($_FILES['picture']['tmp_name'], 'photo/'.$fileName);
	if($move){
		echo "File sudah diupload";
	} else {
		echo "Gagal";
	}
	}else{
		echo "Gagal:" .$fileError;
	}
?>