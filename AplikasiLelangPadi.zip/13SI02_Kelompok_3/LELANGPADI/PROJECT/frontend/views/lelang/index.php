<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\bootstrap\Modal;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $searchModel frontend\models\LelangSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Lelang';
$this->params['breadcrumbs'][] = $this->title;

// var_dump($dataProvider);
// die();
?>




<div class="lelang-index" style = "background-color: rgba();">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::button('Lelang Padi',['value'=>Url::to('index.php?r=lelang/create'),'class'=>'btn btn-success','id'=>'modalButton'])?>
    </p>


<?php

        Modal::begin([

        'header' => '<h4> Lelang </h4>',
        'id' => 'modal',
        'size' => 'modal-lg',
        ]);
        echo "<div id = 'modalContent'> </div>";
        Modal::end();
?>


  <?= GridView::widget([
        'dataProvider' => $dataProvider,
        //'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id_lelang',
            'id_pelelang',
            'jenis_padi',
            'deskripsi_padi:ntext',
            'harga_padi',
            // 'gambar',
            'waktu_akhir',
            [
           'header' => '<center>Keterangan</center>',
            'format' => 'raw',
            

            'value' => function ($model){
                date_default_timezone_set("Asia/Jakarta");
                $end = $model->waktu_akhir;
                $current_date = date("Y-m-d");

                // if($model->id_pelelang)


                if($current_date > $end){

                    // return "<h4><div><center><span class='label label-danger'>Masa Lelang Telah Habis!</span></center></div></h4>";
                
                      return '<div>'.'<center>'.Html::a('Masa Lelang Sudah Habis', ['lelang/view','id'=>$model->id_lelang],['class'=>' btn btn-danger']).'</center>'.'</div>'
                    ;
                }

                else{

               return '<div>'.'<center>'.Html::a('Lihat Lelangan', ['lelang/view','id'=>$model->id_lelang],['class'=>' btn btn-success']).'</center>'.'</div>'
                    ;
            }
        },


            ],

            
        ],
    ]); ?>
</div>

