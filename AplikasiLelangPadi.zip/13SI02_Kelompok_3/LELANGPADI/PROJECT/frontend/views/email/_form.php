<?php
use yii\models\User;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$masuk = Yii::$app->user->identity->id;

 $namalengkap = (new \yii\db\Query())
                    ->select ('namalengkap')
                    ->from('user')
                    ->where(['id' => $masuk])
                    ->scalar();

$model->username_sender = $namalengkap;

 $email = (new \yii\db\Query())
                    ->select ('email')
                    ->from('user')
                    ->where(['id' => $masuk])
                    ->scalar();

$model->sender_email = $email;





/* @var $this yii\web\View */
/* @var $model frontend\models\Email */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="email-form">

    <?php $form = ActiveForm::begin(); ?>

    <!-- <?= $form->field($model, 'username_sender')->textInput(['readonly' => true], ['maxlength' => true]) ?> -->

    <?= $form->field($model, 'sender_email')->textInput(['readonly' => true], ['maxlength' => true]) ?>


    <!-- <?= $form->field($model, 'receiver_name')->textInput(['maxlength' => true]) ?> -->

    <?= $form->field($model, 'reciever_email')->textInput(['readonly' => true], ['maxlength' => true]) ?>


    <?= $form->field($model, 'subject')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'content')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
