<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model frontend\models\Tawar */
/* @var $form yii\widgets\ActiveForm */




    $masuk = Yii::$app->user->identity->id;


?>

<div class="tawar-form" >

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'tanggaltawar')->textInput() ?>

    <?= $form->field($modelel, 'hargaperkg')->textInput(['maxlength' => true, 'readonly'=>true]) ?>

    <?= $form->field($modelel, 'massapadi')->textInput(['id' => 'massapadi', 'readonly' => true], ['maxlength' => true, 'readonly'=>true, 'id' => 'massapadi']) ?>

    <?= $form->field($model, 'kelipatan')->textInput(['id' => 'kelipatan'], ['maxlength' => true, 'id' => 'kelipatan']) ?>

    <?= $form->field($model, 'kenaikanpenawaran')->textInput(['id' => 'kenaikanpenawaran', 'readonly'=>true]) ?>


    <?= $form->field($model, 'hargapadi')->textInput(['id' => 'hargapadi', 'readonly' => true]) ?>
    

    <?= $form->field($model, 'hargapenawaran')->textInput(['id' => 'hargapenawaran', 'readonly' => true]) ?>


    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>






<?php
$script = <<< JS

jQuery(document).ready(function() {
    jQuery('#massapadi' && '#kelipatan').change(function() {
    var massapadi = document.getElementById('massapadi').value;
    var kelipatan = document.getElementById('kelipatan').value;
    var result = parseInt(massapadi) * parseInt(kelipatan)*100;
    if(!isNaN(result)){
        document.getElementById('kenaikanpenawaran').value = result;
    }
    })
})



jQuery(document).ready(function() {
    jQuery('#hargapenawaran').click(function() {
    var kenaikanpenawaran = document.getElementById('kenaikanpenawaran').value;
    var hargapadi = document.getElementById('hargapadi').value;
    var result = parseInt(kenaikanpenawaran) + parseInt(hargapadi);
    if(!isNaN(result)){
        document.getElementById('hargapenawaran').value = result;
    }
    })
})



JS;

$this->registerJs($script);
?>



