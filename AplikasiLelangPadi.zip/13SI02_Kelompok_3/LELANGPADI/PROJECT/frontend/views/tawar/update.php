<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model frontend\models\Tawar */

$this->title = 'Update Tawar: ' . $model->id_tawar;
$this->params['breadcrumbs'][] = ['label' => 'Tawars', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_tawar, 'url' => ['view', 'id' => $model->id_tawar]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="tawar-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
