<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel frontend\models\TawarSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Tawars';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="tawar-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Tawar', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            // 'id_tawar',
            'tanggaltawar',
            // 'id_lelang',
            // 'id_penawar',
            'hargapadi',
            'kelipatan',
            'kenaikanpenawaran',
            'hargapenawaran',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
