<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model frontend\models\Tawar */

$this->title = 'Create Tawar';
$this->params['breadcrumbs'][] = ['label' => 'Tawars', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="tawar-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'modelel' => $modelel,
    ]) ?>

</div>
