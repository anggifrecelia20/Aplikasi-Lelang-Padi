<?php

/* @var $this yii\web\View */

$this->title = 'Aplikasi Lelang Padi';

use frontend\models\Lelang;
use frontend\models\LelangSearch;
use yii\widgets\ListView;
use yii\bootstrap\Modal;
use yii\helpers\Url;
use yii\helpers\Html;


use common\widgets\Alert;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Aplikasi Lelang Padi Online</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
<script type="text/javascript" src="http://yourjavascript.com/21051171187/jquery-touchswipe-min.js"></script>
<script type="text/javascript" src="http://yourjavascript.com/11873115711/jquery-1-12-4-min.js"></script>
<script type="text/javascript" src="http://yourjavascript.com/71712155041/responsive-bootstrap-carousel.js"></script>
  <style>
  .jumbotron {
      background-color: #ffffff;
      color: #000000;
      padding: 0.07px 20px;
      
  }
  .container-fluid {
      padding: 20px 2 0px;
  }
  .bg-grey {
      background-color: #f6f6f6;
  }
  .logo-small {
      color: #f4511e;
      font-size: 50px;
  }
  .logo {
      color: #f4511e;
      font-size: 200px;
  }
  .thumbnail {
      padding: 0 0 15px 0;
      border: none;
      border-radius: 0;
  }
  .thumbnail img {
      width: 100%;
      height: 100%;
      margin-bottom: 10px;
  }
  .carousel-control.right, .carousel-control.left {
     background-image: none;
     color: #f4511e;

  }
  .carousel-indicators li {
      border-color: #f4511e;
  }
  .carousel-indicators li.active {
      background-color: #f4511e;
  }
  .item h4 {
      font-size: 19px;
      line-height: 1.375em;
      font-weight: 400;
      font-style: italic;
      margin: 70px 0;
      color: #f4511e; 
  }
  .item span {
      font-style: normal;
 
  </style>
</head>
<body>
 
<div class="site-index">

    <div class="jumbotron">
        <img src="img/Picture2.png" width="874px" height="226px">

        
</div>

  <div id="myCarousel" class="carousel slide text-center" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <h4>1. Tawar <br><span>Ketemu padi yang sesuai?Segera Klik Tawar, Mungkin anda jadi pemenangnya.</span></h4>
      </div>
      <div class="item">
        <h4>"2. Menang! Yeyy Selamat Anda Jadi Pemenang! <br><span>Pemberitahuan akan dikirimkan langsung kepada anda!</span></h4>
      </div>
      <div class="item">
        <h4>"3. Lakukan transaksi pembayaran."<br><span>Transaksi pembayaran dilakukan dengan kartu kredit.</span></h4>
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>



<div class="judul-home">
  <h2>Rekomendasi</h2>
</div>
<div class="container">
</div> 
  <div class="row">
  
  <?php
  foreach ($rows as $key => $value) {
    # code...
    
?> 
    <div class="col-md-3 col-sm-6  ">
        <span class="thumbnail text-center"> 
           <img src=<?php echo 'images/'.$value['gambar']; ?> height="280px">
            <!-- <h4 class="text-danger"><?php  //echo $modelLelangss[0]->jenis_padi; ?></h4> -->
            
            <div class="ratings">
                    <span class="glyphicon glyphicon-star"></span>
                    <span class="glyphicon glyphicon-star"></span>
                    <span class="glyphicon glyphicon-star"></span>
                    <span class="glyphicon glyphicon-star"></span>
                    <span class="glyphicon glyphicon-star-empty"></span>
            </div>

            <p> <?php echo $value['jenis_padi']; ?></p>
              <p> Lelang berakhir pada <?php echo $value['waktu_akhir']; ?></p>
            

          <hr class="line">
                <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <p>Tawar dari : Rp. <?php echo $value['harga_padi']; ?></p>
                        </div>
                        
                        <div class="col-md-6 col-sm-6">
                          
                         <!-- <button class="btn btn-danger right" > Tawar </button> -->

                           <p>
       <!--  <?= Html::a('Tawar', ['create'], ['class' => 'btn btn-success']) ?> -->

       <?= Html::button('Tawar', ['value'=>Url::to(['tawar/createss', 'id_lelang' => $value['id_lelang']]),'class' => 'btn btn-success', 'id'=>'modalButton']) ?>
                     


                       <?php 
                       Modal::begin([
                        'header' => '<h4>Tawar</h4>',
                        'id' => 'modal',
                        'size' => 'modal-lg',
                        ]);
                       echo "<div id = 'modalContent'></div>";
                       Modal::end();
                        ?>


    </p>


                        </div>

                </div>
            </hr>
        </span>
    </div>
 <?php

 // Yii::$app->session->setFlash('error', 'Tidak dapat membuat Lelang! 
 //                Waktu Akhir berjarak 3 s.d 5 hari dari hari ini. Silahkan buat ulang Lelang Padi Anda');

 }
 ?>     
      
      <!-- END PRODUCTS -->
  </div>
</div>

</body>
</html>

    </div>

    <div class="body-content">

     

    </div>
</div>
