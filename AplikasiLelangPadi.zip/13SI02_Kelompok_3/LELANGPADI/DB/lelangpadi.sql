/*
SQLyog Community v12.2.1 (64 bit)
MySQL - 10.1.21-MariaDB : Database - lelangpadi
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lelangpadi` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `lelangpadi`;

/*Table structure for table `akun` */

DROP TABLE IF EXISTS `akun`;

CREATE TABLE `akun` (
  `nomorAkun` varchar(255) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `PIN` varchar(255) NOT NULL,
  `saldo` varchar(255) NOT NULL,
  `kadaluarsa` date NOT NULL,
  `id_history` int(11) DEFAULT NULL,
  PRIMARY KEY (`nomorAkun`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `akun` */

insert  into `akun`(`nomorAkun`,`fullName`,`PIN`,`saldo`,`kadaluarsa`,`id_history`) values 
('1234','Riahta','0101','80000000','2019-01-01',NULL),
('5678','Mei','0202','89000000','2018-01-01',NULL);

/*Table structure for table `email` */

DROP TABLE IF EXISTS `email`;

CREATE TABLE `email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver_name` varchar(50) NOT NULL,
  `reciever_email` varchar(200) NOT NULL,
  `username_sender` varchar(255) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `email` */

insert  into `email`(`id`,`receiver_name`,`reciever_email`,`username_sender`,`sender_email`,`subject`,`content`) values 
(1,'mayang','mayangbangung35@gmail.com','','','mayang','mayang'),
(2,'mayang','mayangbangung35@gmail.com','','','mayang','mayang'),
(3,'mayang','mayangbangung35@gmail.com','','','mayang','mayang'),
(4,'mayang','mayangbangun35@gmail.com','','','mayang','mayang'),
(5,'mayang','mayangbangun35@gmail.com','Riahtamei','riahta.mei38@gmail.com','tes email','tes email');

/*Table structure for table `emailku` */

DROP TABLE IF EXISTS `emailku`;

CREATE TABLE `emailku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver_name` varchar(50) NOT NULL,
  `receiver_email` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `emailku` */

insert  into `emailku`(`id`,`receiver_name`,`receiver_email`,`subject`,`content`,`attachment`) values 
(1,'evita','evitarindani@gmail.com','evita','evita',NULL);

/*Table structure for table `history` */

DROP TABLE IF EXISTS `history`;

CREATE TABLE `history` (
  `id_history` int(11) NOT NULL AUTO_INCREMENT,
  `id_tawar` int(11) NOT NULL,
  PRIMARY KEY (`id_history`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `history` */

/*Table structure for table `lelang` */

DROP TABLE IF EXISTS `lelang`;

CREATE TABLE `lelang` (
  `id_lelang` int(100) NOT NULL AUTO_INCREMENT,
  `jenis_padi` varchar(100) NOT NULL,
  `deskripsi_padi` varchar(100) NOT NULL,
  `massapadi` varchar(100) NOT NULL,
  `hargaperkg` varchar(100) NOT NULL,
  `harga_padi` varchar(100) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `waktu_awal` date NOT NULL,
  `waktu_akhir` date NOT NULL,
  `id_pelelang` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_lelang`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

/*Data for the table `lelang` */

insert  into `lelang`(`id_lelang`,`jenis_padi`,`deskripsi_padi`,`massapadi`,`hargaperkg`,`harga_padi`,`gambar`,`waktu_awal`,`waktu_akhir`,`id_pelelang`,`status`) values 
(41,'Padi Ramos Merah','Enak dan Berkualitas','10','10000','100000','padi2.jpg','2018-01-12','2018-01-16',11,1);

/*Table structure for table `migration` */

DROP TABLE IF EXISTS `migration`;

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `migration` */

insert  into `migration`(`version`,`apply_time`) values 
('m000000_000000_base',1508922775),
('m130524_201442_init',1508922781);

/*Table structure for table `tawar` */

DROP TABLE IF EXISTS `tawar`;

CREATE TABLE `tawar` (
  `id_tawar` int(11) NOT NULL AUTO_INCREMENT,
  `tanggaltawar` date NOT NULL,
  `id_lelang` int(100) NOT NULL,
  `id_penawar` int(11) NOT NULL,
  `hargapadi` int(100) NOT NULL,
  `kelipatan` int(10) NOT NULL,
  `kenaikanpenawaran` int(100) NOT NULL,
  `hargapenawaran` int(100) NOT NULL,
  PRIMARY KEY (`id_tawar`),
  KEY `fk_1` (`id_lelang`),
  KEY `fk_2` (`id_penawar`),
  CONSTRAINT `fk_1` FOREIGN KEY (`id_lelang`) REFERENCES `lelang` (`id_lelang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_2` FOREIGN KEY (`id_penawar`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=latin1;

/*Data for the table `tawar` */

insert  into `tawar`(`id_tawar`,`tanggaltawar`,`id_lelang`,`id_penawar`,`hargapadi`,`kelipatan`,`kenaikanpenawaran`,`hargapenawaran`) values 
(134,'2018-01-12',41,14,100000,20,20000,120000),
(135,'2018-01-12',41,6,120000,30,30000,150000);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namalengkap` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tanggalahir` date NOT NULL,
  `alamat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `nohp` int(13) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `nokartukredit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `user` */

insert  into `user`(`id`,`namalengkap`,`tanggalahir`,`alamat`,`nohp`,`username`,`auth_key`,`password_hash`,`password_reset_token`,`email`,`status`,`created_at`,`updated_at`,`nokartukredit`) values 
(2,'','0000-00-00','',0,'user','oGBm3Ar2E86DD7PNK6vDeVjPU-ToS-0E','$2y$13$1nQYzwqNisiu6IL3CIm9ZuaGDAmsuz6bgx6B7BUuARKsDbgQSG2gS',NULL,'user@mail.com',10,1512183699,1512183699,'0'),
(3,'','0000-00-00','',0,'meiket','rXY-S-9lnUYPxthcvuX-ukK81O6yhcje','$2y$13$cFYjfxQcLSJ6L3tI2m4uk.ZHADG72..edhhgpijPCwLFlkgXiE6vW',NULL,'meiket@gmail.com',10,1512948146,1512948146,'0'),
(4,'meiketaren','1998-05-27','medan',987666,'meimei','BTbx36cyuQWeWKlsv_nFQT6r6m_UCXUL','$2y$13$.K5g/T4xKHRda9O1SxjL2u/SZtm5k2kLDeKH2LZqbC/aomZjuIJTm',NULL,'meimei@gmail.com',10,1512949728,1512949728,'0'),
(6,'anggi','2017-12-27','aa',9,'anggi','rMm7KyaORKKLgtvVhsZn8NKLunH1lcBr','$2y$13$2Y/uW.qAzvq0skDEMZ8vc.F0iimUDGGhmef7nkeRK0spXSkCZxcy2',NULL,'anggi@mail.com',10,1513009638,1513009638,'0105040002'),
(11,'mei','1998-05-27','medan',99999999,'mei_merchant','yVlhpehnew6wZlRrJR4FFUWeTGdzoqU6','$2y$13$uwf/zrriImLbVzU4lGPWm.ybsdug7tfbtwfGJS1O1SzFIVn3XfICW',NULL,'riahta.mei38@gmail.com',10,1515276669,1515276669,'0105040004'),
(12,'mei','1999-11-17','sitoluama',888888,'mei_normal','6XYOrCWh8KrZorm-9Miveja3rr8ko-kx','$2y$13$aByWxSGBEIlJSMX2QXgTV.Of8t3JbHQliAsvC2WwHGHnmE.iuz3DS',NULL,'mei@mail.com',10,1515276860,1515276860,'0105040001'),
(13,'christine','1998-05-27','laguboti',987654321,'christine','aOwn5X9x9eUFok1J7XjXme9Qio_urIE5','$2y$13$QxWtTokXJtaiaX05lvGleusw/PdNrKMzetx1xOUoMZnwKxpr.1Rbe',NULL,'christine@gmail.com',10,1515449613,1515449613,'0105040003'),
(14,'pratiwi','1998-05-27','medan',987654321,'pratiwi','MAoJX6CK_WzFeAXGUHX6fNjIZtrwwLXZ','$2y$13$0StZyQPRAll5f8uKd38iEOE8bRhZ6UCZneQFusuq0tXNszPb5vsdi',NULL,'pratiwi@gmail.com',10,1515736178,1515736178,'0105040006');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
